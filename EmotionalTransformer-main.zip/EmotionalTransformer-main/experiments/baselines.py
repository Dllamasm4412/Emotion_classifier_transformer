from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Literal

import torch
from torch import nn

from models.cnn_encoder import CnnEncoderConfig, ModalityCNNEncoder
from models.multimodal_transformer import FusionConfig, MultimodalTransformer, Modality


@dataclass
class HeadConfig:
    d_model: int = 64
    hidden: int = 128
    dropout: float = 0.1


class GlobalAvgHead(nn.Module):
    def __init__(self, cfg: HeadConfig) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(cfg.d_model),
            nn.Linear(cfg.d_model, cfg.hidden),
            nn.ReLU(inplace=True),
            nn.Dropout(cfg.dropout),
            nn.Linear(cfg.hidden, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = x.mean(dim=1)
        return self.net(z).squeeze(-1)


class UnimodalCNNRegressor(nn.Module):
    """
    Baseline: CNN encoder + head on a single modality.
    """

    def __init__(self, cnn_cfg: CnnEncoderConfig, head_cfg: HeadConfig) -> None:
        super().__init__()
        self.encoder = ModalityCNNEncoder(cnn_cfg)
        self.head = GlobalAvgHead(head_cfg)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.encoder(x)
        return self.head(h)


class EarlyFusionCNNRegressor(nn.Module):
    """
    Early fusion: concatenate modality encodings along feature dim, then regress.
    """

    def __init__(self, cnn_cfg: CnnEncoderConfig, head_cfg: HeadConfig) -> None:
        super().__init__()
        self.encoders = nn.ModuleDict(
            {
                "ppg": ModalityCNNEncoder(cnn_cfg),
                "resp": ModalityCNNEncoder(cnn_cfg),
                "gsr": ModalityCNNEncoder(cnn_cfg),
            }
        )
        self.head = GlobalAvgHead(HeadConfig(d_model=cnn_cfg.proj_dim * 3, hidden=head_cfg.hidden, dropout=head_cfg.dropout))

    def forward(self, inputs: Dict[Modality, torch.Tensor]) -> torch.Tensor:
        hs = [self.encoders[m](inputs[m]) for m in ("ppg", "resp", "gsr")]
        # Align sequence length by cropping to min length
        min_len = min(h.size(1) for h in hs)
        hs = [h[:, :min_len] for h in hs]
        h_cat = torch.cat(hs, dim=2)
        return self.head(h_cat)


class LateFusionRegressor(nn.Module):
    """
    Late fusion: independent unimodal regressors with averaged predictions.
    """

    def __init__(self, cnn_cfg: CnnEncoderConfig, head_cfg: HeadConfig) -> None:
        super().__init__()
        self.unimodal = nn.ModuleDict(
            {
                "ppg": UnimodalCNNRegressor(cnn_cfg, head_cfg),
                "resp": UnimodalCNNRegressor(cnn_cfg, head_cfg),
                "gsr": UnimodalCNNRegressor(cnn_cfg, head_cfg),
            }
        )

    def forward(self, inputs: Dict[Modality, torch.Tensor]) -> torch.Tensor:
        preds = [self.unimodal[m](inputs[m]) for m in ("ppg", "resp", "gsr")]
        return torch.stack(preds, dim=0).mean(dim=0)


def make_model(
    kind: Literal["cross_attn", "unimodal_ppg", "unimodal_resp", "unimodal_gsr", "early_fusion", "late_fusion"],
    cnn_cfg: CnnEncoderConfig,
    fusion_cfg: FusionConfig,
    head_cfg: HeadConfig,
) -> nn.Module:
    if kind == "cross_attn":
        return MultimodalTransformer(cnn_cfg, fusion_cfg)
    if kind == "early_fusion":
        return EarlyFusionCNNRegressor(cnn_cfg, head_cfg)
    if kind == "late_fusion":
        return LateFusionRegressor(cnn_cfg, head_cfg)
    if kind == "unimodal_ppg":
        return UnimodalCNNRegressor(cnn_cfg, head_cfg)
    if kind == "unimodal_resp":
        return UnimodalCNNRegressor(cnn_cfg, head_cfg)
    if kind == "unimodal_gsr":
        return UnimodalCNNRegressor(cnn_cfg, head_cfg)
    raise ValueError(f"unknown model kind: {kind}")

