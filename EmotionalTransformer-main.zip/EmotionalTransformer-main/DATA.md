# DEAP dataset notes

## What we use (current scope)

- **Raw DEAP recordings**: BioSemi `.bdf` files in `deap/original-data/`
- **Labels**: arousal from `deap/Metadata/metadata_csv/participant_ratings.csv`
- **Modalities**: PPG/BVP, respiration, GSR/EDA (extracted from peripheral channels in raw BDF)

## File layout expected

- `deap/original-data/s01.bdf` … `s30.bdf` (some higher-index subjects may be skipped automatically if they lack `Status` channel)

## Labels format

`deap/Metadata/metadata_csv/participant_ratings.csv` is expected to contain per-participant, per-trial ratings including arousal (typically 1–9).

The loader currently:

- Uses **`Trial` (1–40)** and **`Participant_id`** to align each 60 s trial (from `Status` events) with its **Arousal** score.
- Assigns that arousal value to **every window** extracted from that trial.

## EEG

EEG is present in the raw BDFs (and you have metadata like `deap/Metadata/DEAP_EEG_channels.xlsx`), but **EEG is out of scope for the current implementation**. It remains a future extension.

