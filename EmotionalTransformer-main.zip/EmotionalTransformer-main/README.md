# EmotionalTransformer

Multimodal transformer-based **arousal estimation** on the **DEAP** dataset, following the architecture described in `NNFinalProject.pdf`:

- **Per-modality 1D CNN encoders** for peripheral physiological signals
- **Transformer fusion with cross-attention**
- **Regression head** to predict continuous arousal

## Data

This repo expects **raw DEAP `.bdf`** files under:

- `deap/original-data/s01.bdf` … (subject files)

Labels are read from:

- `deap/Metadata/metadata_csv/participant_ratings.csv`

The current implementation uses peripheral channels:

- **PPG/BVP**: `Plet`
- **Respiration**: `Resp`
- **GSR/EDA**: `GSR1`, `GSR2` (combined as `GSR1 - GSR2`)

Notes:

- Trial boundaries are detected from the `Status` channel (event codes **4=start**, **5=end**) and windows are extracted within each ~60s trial.
- Some BDFs may be skipped automatically if they are missing `Status`.

## Setup

Create a local virtual environment and install dependencies:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Train

The training script automatically selects the best available device:

- **CUDA GPU** if `torch.cuda.is_available()` is true.
- Otherwise **Apple MPS** on Apple Silicon if `torch.backends.mps.is_available()`.
- Otherwise falls back to **CPU**.

Main multimodal model (cross-attention fusion):

```bash
source .venv/bin/activate
python train.py --model cross_attn --epochs 20
```

### Baselines (Experiment 1)

Unimodal baselines:

```bash
python train.py --model unimodal_ppg --epochs 20
python train.py --model unimodal_resp --epochs 20
python train.py --model unimodal_gsr --epochs 20
```

Early / late fusion:

```bash
python train.py --model early_fusion --epochs 20
python train.py --model late_fusion --epochs 20
```

## Repo structure

- `data/deap_loader.py`: DEAP raw BDF loader, preprocessing, trial segmentation, windowing
- `models/cnn_encoder.py`: per-modality 1D CNN encoder
- `models/multimodal_transformer.py`: cross-attention fusion transformer + regression head
- `experiments/baselines.py`: unimodal / early-fusion / late-fusion baselines
- `train.py`: training + evaluation (MSE and Pearson correlation)

## Large files

Large DEAP assets are ignored by Git via `.gitignore`:

- `deap/original-data/`
- `deap/raw-audio/`
- `deap/features/`
