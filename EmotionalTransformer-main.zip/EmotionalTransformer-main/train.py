from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

from data.deap_loader import ChannelMap, WindowConfig, build_windowed_dataset
from experiments.baselines import HeadConfig, FusionConfig, CnnEncoderConfig, make_model


class DeapWindowsDataset(Dataset):
    def __init__(self, X: Dict[str, np.ndarray], y: np.ndarray, idx: np.ndarray) -> None:
        self.X = X
        self.y = y
        self.idx = idx

    def __len__(self) -> int:
        return self.idx.shape[0]

    def __getitem__(self, i: int):
        j = int(self.idx[i])
        return {
            "ppg": torch.from_numpy(self.X["ppg"][j]),
            "resp": torch.from_numpy(self.X["resp"][j]),
            "gsr": torch.from_numpy(self.X["gsr"][j]),
            "y": torch.tensor(self.y[j], dtype=torch.float32),
        }


def make_splits(subject_id: np.ndarray, train_frac: float = 0.7, val_frac: float = 0.15) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(0)
    unique_subj = np.unique(subject_id)
    rng.shuffle(unique_subj)
    n = len(unique_subj)
    n_train = int(round(train_frac * n))
    n_val = int(round(val_frac * n))
    train_subj = unique_subj[:n_train]
    val_subj = unique_subj[n_train : n_train + n_val]
    test_subj = unique_subj[n_train + n_val :]

    train_idx = np.where(np.isin(subject_id, train_subj))[0]
    val_idx = np.where(np.isin(subject_id, val_subj))[0]
    test_idx = np.where(np.isin(subject_id, test_subj))[0]
    return train_idx, val_idx, test_idx


@dataclass
class TrainConfig:
    batch_size: int = 64
    lr: float = 1e-3
    weight_decay: float = 1e-4
    epochs: int = 5


def train_one_epoch(model: nn.Module, loader: DataLoader, optim: torch.optim.Optimizer, device: torch.device) -> float:
    model.train()
    mse = nn.MSELoss()
    total_loss = 0.0
    n = 0
    for batch in loader:
        x = {k: v.to(device) for k, v in batch.items() if k != "y"}
        y = batch["y"].to(device)
        optim.zero_grad()
        preds = model(x)
        loss = mse(preds, y)
        loss.backward()
        optim.step()
        total_loss += loss.item() * y.size(0)
        n += y.size(0)
    return total_loss / max(n, 1)


@torch.no_grad()
def eval_epoch(model: nn.Module, loader: DataLoader, device: torch.device) -> Tuple[float, float]:
    model.eval()
    mse = nn.MSELoss()
    total_loss = 0.0
    ys = []
    preds_all = []
    n = 0
    for batch in loader:
        x = {k: v.to(device) for k, v in batch.items() if k != "y"}
        y = batch["y"].to(device)
        out = model(x)
        loss = mse(out, y)
        total_loss += loss.item() * y.size(0)
        n += y.size(0)
        ys.append(y.cpu().numpy())
        preds_all.append(out.cpu().numpy())
    if n == 0:
        return 0.0, 0.0
    ys_arr = np.concatenate(ys)
    preds_arr = np.concatenate(preds_all)
    num = np.cov(ys_arr, preds_arr, bias=True)[0, 1]
    denom = ys_arr.std() * preds_arr.std()
    corr = float(num / denom) if denom > 0 else 0.0
    return total_loss / n, corr


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, default="cross_attn", help="cross_attn|unimodal_ppg|unimodal_resp|unimodal_gsr|early_fusion|late_fusion")
    parser.add_argument("--epochs", type=int, default=5)
    args = parser.parse_args()

    root = Path(".").resolve()
    window = WindowConfig()
    X, y, subject_id, trial_id = build_windowed_dataset(root, window=window, ch_map=ChannelMap())
    train_idx, val_idx, test_idx = make_splits(subject_id)

    train_ds = DeapWindowsDataset(X, y, train_idx)
    val_ds = DeapWindowsDataset(X, y, val_idx)
    test_ds = DeapWindowsDataset(X, y, test_idx)

    train_loader = DataLoader(train_ds, batch_size=64, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=128)
    test_loader = DataLoader(test_ds, batch_size=128)

    cnn_cfg = CnnEncoderConfig()
    fusion_cfg = FusionConfig()
    head_cfg = HeadConfig()
    model = make_model(args.model, cnn_cfg, fusion_cfg, head_cfg)

    if torch.cuda.is_available():
        device = torch.device("cuda")
        device_name = torch.cuda.get_device_name(device)
    elif torch.backends.mps.is_available():  # Apple Silicon
        device = torch.device("mps")
        device_name = "Apple MPS"
    else:
        device = torch.device("cpu")
        device_name = "CPU"

    print(f"Using device: {device} ({device_name})")
    model.to(device)

    opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)

    for epoch in range(args.epochs):
        train_loss = train_one_epoch(model, train_loader, opt, device)
        val_loss, val_corr = eval_epoch(model, val_loader, device)
        print(f"epoch {epoch+1}: train_mse={train_loss:.4f} val_mse={val_loss:.4f} val_pearson={val_corr:.3f}")

    test_loss, test_corr = eval_epoch(model, test_loader, device)
    print(f"test_mse={test_loss:.4f} test_pearson={test_corr:.3f}")


if __name__ == "__main__":
    main()

