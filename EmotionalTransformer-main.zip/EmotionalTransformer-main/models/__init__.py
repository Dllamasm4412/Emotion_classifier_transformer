"""Model components for the DEAP multimodal transformer."""

