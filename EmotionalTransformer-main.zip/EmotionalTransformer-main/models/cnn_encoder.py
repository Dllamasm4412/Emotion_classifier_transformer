from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn


@dataclass
class CnnEncoderConfig:
    in_channels: int = 1
    hidden_channels: int = 32
    num_layers: int = 3
    kernel_size: int = 7
    proj_dim: int = 64


class ModalityCNNEncoder(nn.Module):
    """
    Small 1D CNN encoder for a single modality.

    Input:  (B, C=1, T)
    Output: (B, T_reduced, proj_dim)
    """

    def __init__(self, cfg: CnnEncoderConfig) -> None:
        super().__init__()
        layers = []
        in_ch = cfg.in_channels
        ch = cfg.hidden_channels
        for _ in range(cfg.num_layers):
            layers.append(
                nn.Conv1d(
                    in_ch,
                    ch,
                    kernel_size=cfg.kernel_size,
                    padding=cfg.kernel_size // 2,
                    stride=2,
                )
            )
            layers.append(nn.BatchNorm1d(ch))
            layers.append(nn.ReLU(inplace=True))
            in_ch = ch
        self.cnn = nn.Sequential(*layers)
        self.proj = nn.Conv1d(ch, cfg.proj_dim, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: (B, 1, T)
        """
        h = self.cnn(x)
        h = self.proj(h)  # (B, D, T_reduced)
        return h.transpose(1, 2)  # (B, T_reduced, D)

