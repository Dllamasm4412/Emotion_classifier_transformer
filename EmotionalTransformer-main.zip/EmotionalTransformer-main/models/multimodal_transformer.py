from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Literal

import torch
from torch import nn

from .cnn_encoder import CnnEncoderConfig, ModalityCNNEncoder


Modality = Literal["ppg", "resp", "gsr"]


@dataclass
class FusionConfig:
    d_model: int = 64
    nhead: int = 4
    num_layers: int = 2
    dim_feedforward: int = 128
    dropout: float = 0.1


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 2000) -> None:
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2, dtype=torch.float32) * (-torch.log(torch.tensor(10000.0)) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0), persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: (B, T, D)
        """
        if x.size(1) > self.pe.size(1):
            raise ValueError("sequence too long for positional encoding buffer")
        return x + self.pe[:, : x.size(1)]


class CrossAttentionBlock(nn.Module):
    """
    One block of self-attention + cross-attention based fusion.
    """

    def __init__(self, cfg: FusionConfig) -> None:
        super().__init__()
        self.self_attn = nn.MultiheadAttention(cfg.d_model, cfg.nhead, dropout=cfg.dropout, batch_first=True)
        self.cross_attn = nn.MultiheadAttention(cfg.d_model, cfg.nhead, dropout=cfg.dropout, batch_first=True)
        self.ff = nn.Sequential(
            nn.Linear(cfg.d_model, cfg.dim_feedforward),
            nn.ReLU(inplace=True),
            nn.Dropout(cfg.dropout),
            nn.Linear(cfg.dim_feedforward, cfg.d_model),
        )
        self.norm1 = nn.LayerNorm(cfg.d_model)
        self.norm2 = nn.LayerNorm(cfg.d_model)
        self.norm3 = nn.LayerNorm(cfg.d_model)
        self.dropout = nn.Dropout(cfg.dropout)

    def forward(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
        # Self-attention within modality
        sa, _ = self.self_attn(q, q, q)
        x = self.norm1(q + self.dropout(sa))
        # Cross-attention: query attends to other modalities
        ca, _ = self.cross_attn(x, k, v)
        x = self.norm2(x + self.dropout(ca))
        # Feedforward
        ff = self.ff(x)
        x = self.norm3(x + self.dropout(ff))
        return x


class MultimodalTransformer(nn.Module):
    """
    CNN encoders + multimodal transformer fusion + regression head.
    """

    def __init__(
        self,
        cnn_cfg: CnnEncoderConfig,
        fusion_cfg: FusionConfig,
    ) -> None:
        super().__init__()
        self.encoders = nn.ModuleDict(
            {
                "ppg": ModalityCNNEncoder(cnn_cfg),
                "resp": ModalityCNNEncoder(cnn_cfg),
                "gsr": ModalityCNNEncoder(cnn_cfg),
            }
        )
        self.pos_encoding = PositionalEncoding(cnn_cfg.proj_dim)
        self.blocks = nn.ModuleList([CrossAttentionBlock(fusion_cfg) for _ in range(fusion_cfg.num_layers)])
        self.head = nn.Sequential(
            nn.LayerNorm(cnn_cfg.proj_dim),
            nn.Linear(cnn_cfg.proj_dim, fusion_cfg.dim_feedforward),
            nn.ReLU(inplace=True),
            nn.Dropout(fusion_cfg.dropout),
            nn.Linear(fusion_cfg.dim_feedforward, 1),
        )

    def forward(self, inputs: Dict[Modality, torch.Tensor]) -> torch.Tensor:
        """
        inputs[mod]: (B, 1, T)
        Returns:
          y: (B,) regression output (arousal)
        """
        h: Dict[Modality, torch.Tensor] = {}
        for m, enc in self.encoders.items():
            h[m] = self.pos_encoding(enc(inputs[m]))

        # Simple fusion: for each modality, attend to concatenation of the others.
        # Here we use PPG as primary, and let it attend to concat(resp, gsr).
        h_ppg = h["ppg"]
        h_resp = h["resp"]
        h_gsr = h["gsr"]
        k_other = torch.cat([h_resp, h_gsr], dim=1)
        v_other = k_other

        x = h_ppg
        for blk in self.blocks:
            x = blk(x, k_other, v_other)

        # Global average pooling over time
        z = x.mean(dim=1)
        y = self.head(z).squeeze(-1)
        return y

