# Developer runbook

This file records how to run and reproduce experiments in this repo.

## Environment

- Python 3.10+ (using local virtualenv `.venv`)
- Install dependencies from `requirements.txt`:
  - `torch`, `numpy`, `scipy`, `pandas`, `mne`

## Data expectations

- Raw DEAP BDF files under `deap/original-data/` (`s01.bdf` …)
- Ratings file: `deap/Metadata/metadata_csv/participant_ratings.csv`

## Commands

- **Create venv and install deps**

  ```bash
  cd EmotionalTransformer
  python -m venv .venv
  source .venv/bin/activate
  pip install -r requirements.txt
  ```

- **Train main cross-attention model**

  ```bash
  source .venv/bin/activate
  python train.py --model cross_attn --epochs 20
  ```

- **Run baselines**

  ```bash
  # Unimodal baselines
  python train.py --model unimodal_ppg --epochs 20
  python train.py --model unimodal_resp --epochs 20
  python train.py --model unimodal_gsr --epochs 20

  # Early / late fusion
  python train.py --model early_fusion --epochs 20
  python train.py --model late_fusion --epochs 20
  ```

All commands assume you run them from the repo root with the venv activated.

## Common failure modes

- **Missing channels**: some BDFs (e.g. certain high-numbered subjects) lack `Status`; the loader logs a skip message and ignores those subjects. If more subjects are missing than expected, inspect their headers with MNE.
- **Event parsing issues**: if trial events change in future data, update `find_deap_trial_events` logic in `data/deap_loader.py`.
- **Memory pressure**: if you hit RAM limits, increase window stride, reduce window length, or subsample subjects during debugging.


