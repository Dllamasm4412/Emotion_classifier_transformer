from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Literal, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import scipy.signal


Modality = Literal["ppg", "resp", "gsr"]
TrialEvents = Tuple[np.ndarray, np.ndarray]  # (trial_starts_samp, trial_ends_samp)


@dataclass(frozen=True)
class DeapPaths:
    root: Path

    @property
    def bdf_dir(self) -> Path:
        return self.root / "deap" / "original-data"

    @property
    def ratings_csv(self) -> Path:
        return self.root / "deap" / "Metadata" / "metadata_csv" / "participant_ratings.csv"


@dataclass(frozen=True)
class WindowConfig:
    sfreq: float = 128.0
    window_sec: float = 10.0
    stride_sec: float = 5.0

    def samples_per_window(self) -> int:
        return int(round(self.window_sec * self.sfreq))

    def samples_per_stride(self) -> int:
        return int(round(self.stride_sec * self.sfreq))


@dataclass(frozen=True)
class ChannelMap:
    ppg: str = "Plet"
    resp: str = "Resp"
    gsr1: str = "GSR1"
    gsr2: str = "GSR2"


def load_participant_ratings(ratings_csv: Path) -> pd.DataFrame:
    """
    Returns a tidy table with columns:
      Participant_id (1-indexed), Trial (1..40), Arousal (float)
    """
    df = pd.read_csv(ratings_csv)
    required = {"Participant_id", "Trial", "Arousal"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"ratings_csv missing columns: {sorted(missing)}")
    return df[["Participant_id", "Trial", "Arousal"]].copy()


def _butter_filter(
    x: np.ndarray,
    sfreq: float,
    *,
    kind: Literal["bandpass", "lowpass"],
    f_lo: Optional[float] = None,
    f_hi: Optional[float] = None,
    order: int = 4,
) -> np.ndarray:
    if x.size == 0:
        return x
    nyq = 0.5 * sfreq

    if kind == "lowpass":
        if f_hi is None:
            raise ValueError("lowpass requires f_hi")
        wn = min(f_hi / nyq, 0.999)
        b, a = scipy.signal.butter(order, wn, btype="lowpass")
    else:
        if f_lo is None or f_hi is None:
            raise ValueError("bandpass requires f_lo and f_hi")
        lo = max(f_lo / nyq, 1e-6)
        hi = min(f_hi / nyq, 0.999)
        if not (lo < hi):
            return x
        b, a = scipy.signal.butter(order, [lo, hi], btype="bandpass")

    return scipy.signal.filtfilt(b, a, x, axis=-1).astype(np.float32, copy=False)


def preprocess_modality(x: np.ndarray, modality: Modality, sfreq: float) -> np.ndarray:
    """
    Light filtering to stabilize training; kept intentionally conservative.
    """
    x = x.astype(np.float32, copy=False)
    x = scipy.signal.detrend(x, axis=-1, type="constant").astype(np.float32, copy=False)

    if modality == "ppg":
        # Typical BVP energy is mostly below ~8 Hz
        return _butter_filter(x, sfreq, kind="bandpass", f_lo=0.5, f_hi=8.0)
    if modality == "resp":
        # Respiration is very low frequency
        return _butter_filter(x, sfreq, kind="bandpass", f_lo=0.05, f_hi=1.0)
    # gsr: very slow; low-pass to remove high-frequency noise
    return _butter_filter(x, sfreq, kind="lowpass", f_hi=1.0)


def zscore_per_subject(windows: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    """
    windows: (N, C, T)
    Normalize each channel based on all windows for that subject.
    """
    mean = windows.mean(axis=(0, 2), keepdims=True)
    std = windows.std(axis=(0, 2), keepdims=True)
    return ((windows - mean) / (std + eps)).astype(np.float32, copy=False)


def make_windows(x: np.ndarray, *, win: int, stride: int) -> np.ndarray:
    """
    x: (T,)
    returns: (N, 1, win)
    """
    if x.ndim != 1:
        raise ValueError(f"expected 1D array, got shape {x.shape}")
    if win <= 0 or stride <= 0:
        raise ValueError("win and stride must be positive")
    if x.shape[0] < win:
        return np.zeros((0, 1, win), dtype=np.float32)

    starts = np.arange(0, x.shape[0] - win + 1, stride, dtype=int)
    out = np.stack([x[s : s + win] for s in starts], axis=0)
    return out[:, None, :].astype(np.float32, copy=False)


def _trial_id_to_experiment_trial(trial: int) -> int:
    # DEAP trials are 1..40; keep as-is.
    return int(trial)


def _subject_id_from_filename(bdf_path: Path) -> int:
    # s01.bdf -> 1
    stem = bdf_path.stem
    if not stem.startswith("s"):
        raise ValueError(f"unexpected bdf filename: {bdf_path.name}")
    return int(stem[1:])


def load_subject_trials_bdf(
    bdf_path: Path,
    *,
    ch_map: ChannelMap,
    target_sfreq: float,
) -> Tuple[float, Dict[Modality, np.ndarray]]:
    """
    Loads continuous raw for one subject, extracts peripheral channels, resamples.

    Returns:
      sfreq: target_sfreq
      signals: dict modality -> 1D array (T,)

    Note:
      This does NOT yet segment per-trial. We’ll window within each trial later once
      we confirm trial boundary handling. For now, we provide continuous signals.
    """
    import mne  # local import to keep dependency optional until used

    raw = mne.io.read_raw_bdf(bdf_path, preload=True, verbose="ERROR")

    needed = [ch_map.ppg, ch_map.resp, ch_map.gsr1, ch_map.gsr2]
    missing = [ch for ch in needed if ch not in raw.ch_names]
    if missing:
        raise ValueError(f"{bdf_path.name}: missing channels {missing}")

    raw.pick_channels(needed)
    raw.resample(target_sfreq, npad="auto")

    data = raw.get_data()  # shape (4, T)
    ppg = data[needed.index(ch_map.ppg)]
    resp = data[needed.index(ch_map.resp)]
    gsr1 = data[needed.index(ch_map.gsr1)]
    gsr2 = data[needed.index(ch_map.gsr2)]
    gsr = gsr1 - gsr2

    return float(raw.info["sfreq"]), {
        "ppg": preprocess_modality(ppg, "ppg", float(raw.info["sfreq"])),
        "resp": preprocess_modality(resp, "resp", float(raw.info["sfreq"])),
        "gsr": preprocess_modality(gsr, "gsr", float(raw.info["sfreq"])),
    }


def list_bdf_files(bdf_dir: Path) -> List[Path]:
    return sorted(bdf_dir.glob("s*.bdf"))


def find_deap_trial_events(raw, *, start_code: int = 4, end_code: int = 5) -> TrialEvents:
    """
    DEAP raw BDF contains a `Status` stim channel. Empirically (s01.bdf):
      - code 4 occurs 40 times and marks trial start
      - code 5 occurs 40 times and marks trial end (~60.06s after code 4)
    """
    import mne

    events = mne.find_events(raw, stim_channel="Status", verbose="ERROR")
    starts_all = events[events[:, 2] == start_code][:, 0]
    ends_all = events[events[:, 2] == end_code][:, 0]
    if len(starts_all) == 0 or len(ends_all) == 0:
        raise ValueError("could not find trial boundary events on Status channel")

    # Pair each start with the first subsequent end.
    paired_starts: list[int] = []
    paired_ends: list[int] = []
    j = 0
    for s in starts_all:
        while j < len(ends_all) and ends_all[j] <= s:
            j += 1
        if j >= len(ends_all):
            break
        paired_starts.append(int(s))
        paired_ends.append(int(ends_all[j]))
        j += 1

    if not paired_starts:
        raise ValueError("no valid start/end trial pairs found")

    return np.asarray(paired_starts, dtype=int), np.asarray(paired_ends, dtype=int)


def build_windowed_dataset(
    repo_root: Path,
    *,
    window: WindowConfig = WindowConfig(),
    ch_map: ChannelMap = ChannelMap(),
    subject_ids: Optional[Sequence[int]] = None,
    start_code: int = 4,
    end_code: int = 5,
) -> Tuple[Dict[Modality, np.ndarray], np.ndarray, np.ndarray, np.ndarray]:
    """
    Build windowed dataset aligned to DEAP 60s trial segments.

    Returns:
      X: dict modality -> (N, 1, win)
      y: (N,) arousal
      subject_id: (N,)
      trial_id: (N,) 1..num_trials
    """
    import mne  # local import

    paths = DeapPaths(repo_root)
    ratings = load_participant_ratings(paths.ratings_csv)

    bdfs = list_bdf_files(paths.bdf_dir)
    if subject_ids is not None:
        keep = set(int(s) for s in subject_ids)
        bdfs = [p for p in bdfs if _subject_id_from_filename(p) in keep]

    win = window.samples_per_window()
    stride = window.samples_per_stride()

    X_acc: Dict[Modality, List[np.ndarray]] = {"ppg": [], "resp": [], "gsr": []}
    y_acc: List[float] = []
    subj_acc: List[int] = []
    trial_acc: List[int] = []

    for bdf in bdfs:
        sid = _subject_id_from_filename(bdf)

        raw_full = mne.io.read_raw_bdf(bdf, preload=True, verbose="ERROR")
        needed = [ch_map.ppg, ch_map.resp, ch_map.gsr1, ch_map.gsr2, "Status"]
        missing = [ch for ch in needed if ch not in raw_full.ch_names]
        if missing:
            print(f"[deap_loader] skipping {bdf.name}: missing channels {missing}")
            continue

        try:
            # Find trial events at the original sampling rate for reliable timing.
            starts_orig, ends_orig = find_deap_trial_events(raw_full, start_code=start_code, end_code=end_code)
        except ValueError as e:
            print(f"[deap_loader] skipping {bdf.name} due to event error: {e}")
            continue

        orig_sfreq = float(raw_full.info["sfreq"])
        # Convert boundaries to target sampling rate indices after resampling.
        scale = window.sfreq / orig_sfreq
        starts = np.round(starts_orig * scale).astype(int)
        ends = np.round(ends_orig * scale).astype(int)
        num_trials = len(starts)

        # Now create a copy with only signal channels and resample.
        raw = raw_full.copy().pick_channels([ch_map.ppg, ch_map.resp, ch_map.gsr1, ch_map.gsr2])
        raw.resample(window.sfreq, npad="auto")
        data = raw.get_data()  # (4, T)

        ppg = data[0]
        resp = data[1]
        gsr = data[2] - data[3]

        # Preprocess full streams once; then slice by trial.
        sf = float(raw.info["sfreq"])
        ppg = preprocess_modality(ppg, "ppg", sf)
        resp = preprocess_modality(resp, "resp", sf)
        gsr = preprocess_modality(gsr, "gsr", sf)

        # Ratings: Trial is 1-indexed and aligned to event order.
        sid_ratings = ratings[ratings["Participant_id"] == sid].set_index("Trial")["Arousal"]

        subj_windows: Dict[Modality, List[np.ndarray]] = {"ppg": [], "resp": [], "gsr": []}
        subj_y: List[float] = []
        subj_trial: List[int] = []

        for t in range(1, num_trials + 1):
            if t not in sid_ratings.index:
                continue
            arousal = float(sid_ratings.loc[t])

            s = int(starts[t - 1])
            e = int(ends[t - 1])

            w_ppg = make_windows(ppg[s:e], win=win, stride=stride)
            w_resp = make_windows(resp[s:e], win=win, stride=stride)
            w_gsr = make_windows(gsr[s:e], win=win, stride=stride)

            n = min(w_ppg.shape[0], w_resp.shape[0], w_gsr.shape[0])
            if n == 0:
                continue

            subj_windows["ppg"].append(w_ppg[:n])
            subj_windows["resp"].append(w_resp[:n])
            subj_windows["gsr"].append(w_gsr[:n])
            subj_y.extend([arousal] * n)
            subj_trial.extend([t] * n)

        if not subj_y:
            continue

        # Per-subject normalization (per modality, single channel)
        for m in ("ppg", "resp", "gsr"):
            w = np.concatenate(subj_windows[m], axis=0)
            X_acc[m].append(zscore_per_subject(w))

        y_acc.extend(subj_y)
        subj_acc.extend([sid] * len(subj_y))
        trial_acc.extend(subj_trial)

    X = {m: np.concatenate(X_acc[m], axis=0) if X_acc[m] else np.zeros((0, 1, win), np.float32) for m in X_acc}
    y = np.asarray(y_acc, dtype=np.float32)
    subject_id = np.asarray(subj_acc, dtype=np.int32)
    trial_id = np.asarray(trial_acc, dtype=np.int32)
    return X, y, subject_id, trial_id

