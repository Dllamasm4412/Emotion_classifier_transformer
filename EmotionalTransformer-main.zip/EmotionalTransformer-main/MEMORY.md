# Project memory (keep updated)

This file is the single source of truth for decisions we don’t want to forget while implementing the DEAP multimodal transformer.

## Data location

- **Raw DEAP BDF**: `deap/original-data/sXX.bdf`
- **Ratings/labels CSV**: `deap/Metadata/metadata_csv/participant_ratings.csv`

## Modalities (current scope)

- **PPG/BVP (plethysmograph)**: `Plet` (from raw BDF, `s01.bdf` header)
- **Respiration**: `Resp` (from raw BDF, `s01.bdf` header)
- **GSR/EDA**: `GSR1`, `GSR2` (from raw BDF, `s01.bdf` header)
  - We will derive a single GSR stream as `GSR = GSR1 - GSR2` unless evidence suggests otherwise.

## Preprocessing (to be finalized after channel confirmation)

- **Target sampling rate**: 128 Hz (resample from original 512 Hz)
- **Window length / stride**: 10 s windows, 5 s stride (default `WindowConfig`)
- **Filtering** (per modality, after resample):
  - PPG: detrend + 4th-order Butterworth bandpass 0.5–8 Hz
  - Resp: detrend + 4th-order Butterworth bandpass 0.05–1 Hz
  - GSR: detrend + 4th-order Butterworth lowpass ≤ 1 Hz
- **Normalization**: per-subject, per-modality z-score over all that subject’s windows

## Labels

- **Target**: arousal (DEAP 1–9)
- **Supervision**: trial-level arousal label assigned to all windows within that trial
- **Task type**: regression first (MSE + Pearson), optional discretization later

## Splits (avoid leakage)

- **Primary**: subject-independent split (participants separated across train/val/test)
- **Strategy**: random shuffle of unique subjects with fixed RNG seed, then 70/15/15 train/val/test split
- **Seed(s)**: NumPy RNG seed = 0 in `make_splits`


